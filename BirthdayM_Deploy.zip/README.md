# Birthday Message Scheduler

A web application that allows users to schedule birthday and special occasion messages to be automatically sent via email at specified dates and times.

## Features

- Schedule personalized messages with name, email, phone number
- Set specific date and time for message delivery
- Automatic email sending at scheduled time
- View all scheduled messages
- Delete scheduled messages

## Technologies Used

- Frontend: HTML5, CSS3, JavaScript (ES6)
- Backend: PHP
- Database: MongoDB
- Email: PHPMailer with SMTP

## Setup Instructions

1. **Prerequisites**
   - XAMPP (Apache, PHP)
   - MongoDB
   - (Optional) Composer (for enhanced PHPMailer and MongoDB driver functionality)

2. **Database Setup**
   - Make sure MongoDB is running on your system
   - No need to manually create collections - they will be created automatically

3. **Configuration**
   - Update `config.php` with your database credentials if needed:
     ```php
     define('MONGO_HOST', 'localhost');
     define('MONGO_PORT', '27017');
     define('MONGO_DB', 'birthday_scheduler');
     ```
   - Configure your email settings:
     ```php
     define('SMTP_HOST', 'smtp.gmail.com'); // Your SMTP server
     define('SMTP_PORT', 587);              // SMTP port
     define('SMTP_USER', 'your-email@gmail.com'); // Your email
     define('SMTP_PASS', 'your-app-password');    // Your app password
     ```

4. **Install Dependencies**
   - Option A (Recommended): Install MongoDB PHP driver and PHPMailer via Composer:
     ```bash
     cd c:\xampp-new\htdocs\BirthdayM
     composer require mongodb/mongodb phpmailer/phpmailer
     ```
   - Option B (Alternative): The application includes fallback implementations that don't require Composer, but email functionality may be more limited

5. **Set Up Cron Job for Automatic Message Sending**
   - On Windows, create a scheduled task that runs `cron_runner.php` every minute
   - On Linux/Mac, add this line to your crontab (`crontab -e`):
     ```bash
     * * * * * /usr/bin/php /path/to/cron_runner.php
     ```

6. **Access the Application**
   - Open your browser and navigate to http://localhost/BirthdayM

## How to Use

1. Enter the recipient's name and email address
2. Optionally add a phone number for SMS notifications
3. Select the date and time for message delivery
4. Write your birthday or special occasion message
5. Click "Schedule Message" to save
6. The message will be delivered automatically at the scheduled time

## Security Considerations

- Use app passwords for Gmail accounts instead of regular passwords
- Validate and sanitize all inputs
- Secure database credentials
- Implement rate limiting to prevent abuse

## Customization

- Modify the CSS in `styles.css` to change the appearance
- Update email templates in `send_email.php`
- Extend functionality to include SMS notifications
- Add user authentication for multi-user support

## Troubleshooting

- Ensure Apache is running in XAMPP
- Verify MongoDB is running on your system
- Check email settings are correct
- Review error logs for debugging information